import os
import pathlib
import launch
from launch_ros.actions import Node
from launch import LaunchDescription

from ament_index_python.packages import get_package_share_directory
from webots_ros2_driver.webots_launcher import WebotsLauncher

from webots_ros2_driver.webots_controller import WebotsController


# from webots_ros2_driver.utils import get_wsl_ip_address, is_wsl

#Import per settare la porta

def generate_launch_description():
    package_dir = get_package_share_directory('webots_hospital_tiago')

    ''' LOCALIZATION SIMULATION'''
    robot_description = pathlib.Path(os.path.join(package_dir, 'resource', 'TiagoBase_localization.urdf')).read_text()
    human_description = pathlib.Path(os.path.join(package_dir, 'resource', 'human.urdf')).read_text()

    webots = WebotsLauncher(
        world=os.path.join(package_dir, 'worlds', 'webots_hospital_tiago.wbt'),

    )

    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': '<robot name=""><link name=""/></robot>'
        }],
    )


    ''' WEBOTS CONTROLLER'''
    tiago_base_driver = WebotsController(
        robot_name= 'TIAGo Base',
        parameters=[
            {'robot_description': robot_description,
            'use_sim_time': True,
            'set_robot_state_publisher': True}
            ] ,
        port="1234",
        respawn=True
    )

    # Si lancia anche il driver human 
    human_driver = WebotsController(
        robot_name= 'human_1',
        parameters=[
            {'robot_description': human_description,
            'use_sim_time': True}
            ] ,
        port="1234",
        respawn=True
    )

    return LaunchDescription([
        # WORLD SIMULATION
        webots,   
        tiago_base_driver,
        human_driver,
        launch.actions.RegisterEventHandler(
            event_handler=launch.event_handlers.OnProcessExit(
                target_action=webots,
                on_exit=[launch.actions.EmitEvent(event=launch.events.Shutdown())],
            )
        )
    ])
